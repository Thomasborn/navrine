import React, { useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { ArrowRight, Menu, Play, Star, ArrowUpRight } from "lucide-react";
import { cn } from "../utils/cn";

export function Landing() {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -100]);

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-white selection:text-black">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-6 mix-blend-difference">
        <div className="text-2xl font-bold tracking-tighter">TENSTUD</div>
        <button className="flex items-center gap-2 text-sm font-medium uppercase tracking-widest hover:opacity-70 transition-opacity">
          Menu <Menu className="w-5 h-5" />
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex flex-col justify-center px-6 md:px-12 lg:px-24 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://picsum.photos/seed/tenstud-hero/1920/1080?blur=2"
            alt="Hero Background"
            className="w-full h-full object-cover opacity-30"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#050505]/50 to-[#050505]" />
        </div>

        <div className="relative z-10 max-w-5xl mt-20">
          <motion.h1
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-[12vw] md:text-[8vw] leading-[0.85] font-bold tracking-tighter uppercase mb-8"
          >
            We build <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-white/40">
              tech experiences
            </span>{" "}
            <br />
            for brands
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="flex items-center gap-4"
          >
            <button className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-black transition-colors group">
              <ArrowRight className="w-6 h-6 -rotate-45 group-hover:rotate-0 transition-transform duration-300" />
            </button>
            <span className="text-sm font-medium uppercase tracking-widest opacity-60">
              Scroll to explore
            </span>
          </motion.div>
        </div>
      </section>

      {/* What We've Built */}
      <section className="py-24 px-6 md:px-12 lg:px-24">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-6">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-widest text-white/50 mb-4">
              What We've Built
            </h2>
            <p className="text-2xl md:text-4xl font-medium max-w-2xl leading-tight">
              Proven projects that merged brand storytelling and tech.
            </p>
          </div>
          <a
            href="#"
            className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-widest hover:opacity-70 transition-opacity border-b border-white/20 pb-1"
          >
            View All Projects <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            {
              title: "DermaScience AR Quest",
              client: "Paragon Beauty Science Tech 2026",
              image: "https://picsum.photos/seed/derma/800/1000",
              tags: ["AR", "Web"],
            },
            {
              title: "Beauty Tech Global Atlas",
              client: "Paragon Beauty Science Tech 2026",
              image: "https://picsum.photos/seed/atlas/800/1000",
              tags: ["Interactive", "Web3D"],
            },
            {
              title: "IBM Ferrari F1 Car AR Experience",
              client: "IBM",
              image: "https://picsum.photos/seed/ibm/800/1000",
              tags: ["AR", "Mobile"],
            },
          ].map((project, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className={cn(
                "group cursor-pointer",
                idx === 2 ? "md:col-span-2 md:w-1/2 md:mx-auto" : "",
              )}
            >
              <div className="relative aspect-[4/5] overflow-hidden bg-white/5 mb-6 rounded-lg">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
                    <ArrowUpRight className="w-8 h-8 text-white" />
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[10px] uppercase tracking-widest px-3 py-1 border border-white/20 rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <h3 className="text-2xl font-bold mb-1">{project.title}</h3>
              <p className="text-white/50 text-sm">{project.client}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Services */}
      <section className="py-24 px-6 md:px-12 lg:px-24 bg-white text-black">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-6">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-widest text-black/50 mb-4">
              You Dream It. We Build It.
            </h2>
            <p className="text-3xl md:text-5xl font-bold tracking-tight max-w-2xl leading-tight">
              Our Services
            </p>
          </div>
          <a
            href="#"
            className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-widest hover:opacity-70 transition-opacity border-b border-black/20 pb-1"
          >
            Explore All Services <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="border-t border-black/10">
          {[
            "Software Development",
            "AI Development",
            "Game Development",
            "Interactive Art Development",
          ].map((service, idx) => (
            <div
              key={idx}
              className="group border-b border-black/10 py-8 md:py-12 flex items-center justify-between cursor-pointer hover:bg-black/5 transition-colors px-4 -mx-4"
            >
              <h3 className="text-3xl md:text-6xl font-bold tracking-tighter group-hover:translate-x-4 transition-transform duration-300">
                {service}
              </h3>
              <ArrowUpRight className="w-8 h-8 md:w-12 md:h-12 opacity-0 group-hover:opacity-100 -translate-x-4 group-hover:translate-x-0 transition-all duration-300" />
            </div>
          ))}
        </div>
      </section>

      {/* About */}
      <section className="py-32 px-6 md:px-12 lg:px-24 relative overflow-hidden">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-sm font-bold uppercase tracking-widest text-white/50 mb-8">
            Creative Marketing Technology Studio
          </h2>
          <p className="text-2xl md:text-4xl lg:text-5xl font-medium leading-tight md:leading-tight lg:leading-tight">
            We are an award-winning creative technology studio in Bintaro,
            founded in 2021. As a dedicated small team, we provide personalized
            service and agile solutions. We pride ourselves on serving leading
            brands through creativity and emerging technologies.
          </p>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 md:px-12 lg:px-24 border-t border-white/10">
        <h2 className="text-sm font-bold uppercase tracking-widest text-white/50 mb-16">
          Trusted by Leading Brands
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {[
            {
              quote:
                "Tenstud really brought our ideas to life. Their smooth and efficient process made everything easier, and we're excited to work with them again on our next project because of how helpful they are.",
              author: "Adrianus Aristo H.",
              role: "Creative Team at BOSS Creator",
            },
            {
              quote:
                "We're a financial services company that hired Tenstud to build our digital presence. They took the time to fully understand our business and audience, creating a clear, confident digital identity that truly fits who we are.",
              author: "Petrus Hadi Satria Bapa",
              role: "Managing Partner at Mesana Investama Utama",
            },
            {
              quote:
                "Tenstud has been our trusted partner for years, delivering VR, AR, sensory motion, and AI projects from start to finish. The team is responsive, professional, and always on time. High-end design, deep client understanding, and consistently outstanding results.",
              author: "Jessica Tanasaleh",
              role: "Sub-Department Head Multimedia & Corporate at PT Gajah Tunggal Tbk",
            },
          ].map((testimonial, idx) => (
            <div key={idx} className="flex flex-col">
              <div className="flex gap-1 mb-6">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="w-4 h-4 fill-white text-white" />
                ))}
              </div>
              <p className="text-lg leading-relaxed mb-8 flex-1">
                "{testimonial.quote}"
              </p>
              <div>
                <h4 className="font-bold">{testimonial.author}</h4>
                <p className="text-sm text-white/50">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Products */}
      <section className="py-24 px-6 md:px-12 lg:px-24 bg-zinc-900">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1">
            <h2 className="text-sm font-bold uppercase tracking-widest text-white/50 mb-4">
              From Services to Products
            </h2>
            <h3 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
              Through our experience, we have learned how to solve business
              problems using digital products
            </h3>
            <p className="text-lg text-white/70 mb-8 max-w-xl">
              Discover our suite of products designed to accelerate your digital
              transformation and marketing efforts.
            </p>
            <button className="px-8 py-4 bg-white text-black font-bold uppercase tracking-widest text-sm rounded-full hover:bg-white/90 transition-colors">
              View Products
            </button>
          </div>
          <div className="flex-1 w-full">
            <div className="aspect-video bg-black rounded-xl overflow-hidden relative border border-white/10">
              <img
                src="https://picsum.photos/seed/product/800/450"
                alt="Product Showcase"
                className="w-full h-full object-cover opacity-60"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 cursor-pointer hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 text-white ml-1 fill-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-32 px-6 md:px-12 lg:px-24 text-center border-t border-white/10">
        <h2 className="text-[8vw] md:text-[6vw] font-bold tracking-tighter uppercase leading-[0.9] mb-12">
          Ready to craft <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-white/40">
            fruitful experiences
          </span>{" "}
          <br />
          today?
        </h2>

        <button className="px-10 py-5 bg-white text-black font-bold uppercase tracking-widest text-sm rounded-full hover:bg-white/90 transition-colors mb-24">
          Let's Talk
        </button>

        <div className="flex flex-col md:flex-row justify-between items-center gap-6 text-sm text-white/50 font-medium uppercase tracking-widest">
          <div>© 2026 TENSTUD. ALL RIGHTS RESERVED.</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">
              Instagram
            </a>
            <a href="#" className="hover:text-white transition-colors">
              LinkedIn
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Email
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
